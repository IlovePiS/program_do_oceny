using System.Windows.Forms;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Mila_Jonerzy2
{
    public partial class Form1 : Form
    {
        // quiz game variables
        int correctAnswer;
        int questionNumber = 1;
        int score;
        int percentage;
        int totalQuestions;
        public Form1()
        {
            InitializeComponent();
            askQuestion(questionNumber);
            totalQuestions = 8;
        }
        private void checkAnswerEvent(object sender, EventArgs e)
        {
            var senderObject = (Button)sender;
            int buttonTag = Convert.ToInt32(senderObject.Tag);
            if (buttonTag == correctAnswer)
            {
                score++;
            }
            if (questionNumber == totalQuestions)
            {
                // work out the percentage
                percentage = (int)Math.Round((double)(score * 100) / totalQuestions);
                MessageBox.Show(
                "Quiz Ended!" + Environment.NewLine +
                "You have answered " + score + " questions correctly." + Environment.NewLine +
                "Your total percentage is " + percentage + "%" + Environment.NewLine +
                "Click OK to play again"
                );
                score = 0;
                questionNumber = 0;
                askQuestion(questionNumber);
            }
            questionNumber++;
            askQuestion(questionNumber);
        }
        private void askQuestion(int qnum)
        {
            switch (qnum)
            {
                case 1:
                    pictureBox1.Image = Properties.Resources.carmelo;
                    lblQuestion.Text = "Co to za koszykarz?";
                    button1.Text = "Carmelo Anthony";
                    button2.Text = "James Harden";
                    button3.Text = "Stephen Curry";
                    button4.Text = "Russell Westbrook";
                    correctAnswer = 1;
                    break;
                case 2:
                    pictureBox1.Image = Properties.Resources.stephen;
                    lblQuestion.Text = "Jak sie nazywa sportowiec na zdjeciu?";
                    button1.Text = "Arnold Schwarzenegger";
                    button2.Text = "Wojciech szczensny";
                    button3.Text = "Stephen Curry";
                    button4.Text = "delta to b2 - 4ac";
                    correctAnswer = 3;
                    break;
                case 3:
                    pictureBox1.Image = Properties.Resources.lebron;
                    lblQuestion.Text = "Kto to jest?";
                    button1.Text = "Przemyslaw Grosicki";
                    button2.Text = "Wojtek Bartecki";
                    button3.Text = "Magda Gessler";
                    button4.Text = "LeBron James";
                    correctAnswer = 4;
                    break;
                case 4:
                    pictureBox1.Image = Properties.Resources.kevin;
                    lblQuestion.Text = "A to kto?";
                    button1.Text = "�wi�ty Miko�aj";
                    button2.Text = "Rick Sanchez";
                    button3.Text = "Kevin Durant";
                    button4.Text = "Giannis Antetokounmpo";
                    correctAnswer = 3;
                    break;
                case 5:
                    pictureBox1.Image = Properties.Resources.kawhi;
                    lblQuestion.Text = "Koszykarz na foci to?";
                    button1.Text = "Kawhi Monzalez";
                    button2.Text = "Carmelo Anthony";
                    button3.Text = "Kevin Durant";
                    button4.Text = "Bille Eilish";
                    correctAnswer = 1;
                    break;
                case 6:
                    pictureBox1.Image = Properties.Resources.giannis;
                    lblQuestion.Text = "Jak on ma na imie?";
                    button1.Text = "Samsung Galaxy J28 ^_^";
                    button2.Text = "Konik Polny";
                    button3.Text = "Giannis Antetokounmpo";
                    button4.Text = "Gigabyte G27Q";
                    correctAnswer = 3;
                    break;
                case 7:
                    pictureBox1.Image = Properties.Resources.chris;
                    lblQuestion.Text = "Ten wariat to?";
                    button1.Text = "Puste";
                    button2.Text = "Tygrysi";
                    button3.Text = "Chris Paul";
                    button4.Text = "Robert Kostecki";
                    correctAnswer = 3;
                    break;
                case 8:
                    pictureBox1.Image = Properties.Resources.damian;
                    lblQuestion.Text = "Fotografia przedstawia koszykarza o imieniu?";
                    button1.Text = "Maltazar";
                    button2.Text = "Dell Alienware AW3423DW QD-OLED";
                    button3.Text = "Monito";
                    button4.Text = "Damian Lillard";
                    correctAnswer = 4;
                    break;
            }
        }
    }
}